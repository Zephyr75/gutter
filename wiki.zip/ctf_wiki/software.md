# Fundamental security mechanisms

`Isolation` Isolate two components from each other. One component cannot acces data/code of the other component except through a well-defined API  

`Least privilege` The principle of least privilege ensures that a component has the least privilege needed to function  
- Any further removed privilege reduces functionality
- Any added privilege will not increase functionality
- This property constraints an attacker in the obtainable privilege  

`Fault compartments` Seperate individual components into smallest functional entity possible. These units contain faults to individual components. Allow abstraction and permission checks at boundaries   

`Trust and correctness` Specific components are assumed to be trusted and correct according to a specification  

`OS abstraction`
- Single domain OS
    - A single layer, no isolation or compartimentalization
    - All code runs in the same domain: the applcation can directly call into operating system drivers
    - High performance, ofter used in embedded systems
- Monolithic OS
	- Two layers: the operating sytem and applications
	- The OS manages resources and orchestrates access
	- Applications are unprivileged, must request access from the OS
	- Linux fully and Windows mostly follows this approach for performance (isolating individual components is expensive)
- Micro Kernel
	- Many layers: each component is a seperate process
	- Only essential parts are privileged
	- Applications request access from different OS process
- Library OS
	- Few thin layers, flat struture
	- Micro-kernel exposes bare OS services
	- Each application brings all necessary OS components

# Attack scenarios

`Memory corruption` Unintended modification of memory location due to missing/ faulty safety check

`Denial of Service [DoS]` Prohibit service use by overwhelming it

`Leak information` Access sensitive data through an unintended transfer or information

`Privilege excalation` An attacker gets higher privileges in an unintended way

## Code execution

`Control flow Hijacking` Attack primitive that allows the adversary to redirect control flow to locations that would not be reached in a benign execution. It requires:
- Knowledge of the location of the code pointer
- Knowledge of the code target
- Existing code and control flow must be use the compromised pointer

`Code injection` Instead of modifying/overwriting code, inject new code into the address space of the process. It requires :
- Knowledge of the location of a writable memory area
- Memory area must be executable
- Control flow must be hijacked/redirected to injected code
- Contruction of shellcode
- Code can be injected either on the heap or on the stack

```c
void vuln(char* u1) {
    // strlen(u1) < MAX?
    char tmp[MAX];
    strcpy(tmp, u1);
    ...
}
vuln(&exploit);
```

`Code reuse` Instead of injecting code, reuse code of the program. The main idea is to stitch together existing code snippets to execute new arbitrary behavior. It requires :
- Knowledge of a writable memory area that contains invocation frames
- Knowledge of executable code snippets
- Control flow must be hijacked/redirected to prepared invocation frames
- Contruction of ROP payload 

`Data corruption` This attack vector locates existing code and modifies it to execute the attacker’s computation. It requires :
- Knowledge of the code location
- Area must be writable
- Program must execute that code on benign code path


# Defenses

`Data Execution Prevention [DEP]` Enforces code integrity on page granularity. Each page in the memory have an executable bit. It is either set to writable or to executable.

`Sandboxing` Prevents a process from accessing system resources or corruptin other processes

`Address Space Layout Randomization [ASLR]` Randimize the location of data regions and codes

`Stack canaries` Place in memory a random value chosen at program start just before the stack return pointer. If the canary value changes, then the program will assume that there has been some overflow and will stop execution

`Safe Exception Handling [SEH]` Pre-defined set of handler addresses to make sure that after an error there is no undefined behaviour. However the system can only execute a pre-defined set of error handling functions

`Control Flow Integrity [CFI]` Ensures the control flow of the application never leaves the predetermined, valid control flow defined at the source code/application level

`Code Pointer Integrity [CPI]` Protect all code pointers at all times

`Sanitizer` Allow early bug detection
- `AddressSanitizer` enforces probabilistic memory safety by recording metadata for every allocated object and checking every memory read/write
- `MemorySanitizer` targets uninitialized data
- `ThreadSanitizer` targets data races
- `UndefinedBahaviorSanitizer` finds different kinds of undefined behavior
- `HexType` targets type confusion


# Software testing

`Secure Development Cycle [SDC]`
- Requirement analysis
- Design
- Implementation
- Testing
- Release
- Maintenance

`Control flow` All possible paths of the program  

`Data flow` All possible values for the variables locations that are used by the program

Automatic testing:
- `Static analysis` Analyze the program without executing it
- `Symbolic analysis` Means of analyzing the program to determine what input causes each part of the program to execute

Coverage as metric:
- `Statement coverage` Doesn't imply full coverage
- `Branch coverage` Cannot cover all paths, try to evaluate every statement to both true and false but will not try all possible combinations of statements thus its incompletet path coverage

## Fuzzing

Input generation:
- `Dumb fuzzing` is unaware of the input structure, it randomly mutates inputs
- `Generation based fuzzing` has a model that describes inputs, input generation producces new input seeds in each round
- `Mutation based fuzzing` leverages a set of valid seed inputs, input generation modifies inputs based on feedback from previous round

A leverage program structure:
- `Black box` fuzzing is unaware of the program structure
- `Grey box` leverages program instructions based on previous inputs (trace information)
- `White box` fuzzing leverages semantic program analysis to mutate input (increase code coverage)

`Coverage Wall` No longer makes progress because checks of the program are complex and it is unlikely that a fuzzer will randomly generate inputs that satisfy all these checks

Different types of fuzzers:
- `Black box` generates random inputs
- `Model based` generates grammar based input
- `Coverage-guided fuzzing, feedback loop` algo to generate new inputs



