# Exiftool

`Exiftool` read, write and edit file metadata

[Exiftool cheatsheet](https://gist.github.com/rjames86/33b9af12548adf091a26)

# Brute force archives

Extract password hash:

```bash
// RAR archives
rar2john

// ZIP archives
zip2john
```

Brute force passwords:
```bash
john --show hashes.txt
```


## With known file inside

`PkCrack` tool to crack archive without guessing the password by knowing at least one file in the archive

1. Get known file name -> jquery-1.12.4.min.js 
2. Copy file content to new file -> jquery.txt
3. Create archive containing new file using the same archiving method as the encrypted archive -> clear.zip
4. Run following command
```bash
./pkcrack-1.2.2/src/pkcrack -C zip-2.zip -c jquery-1.12.4.min.js -P clear.zip -p jquery.txt -d decrypted -a
```

# ImageMagick

TODO: imagemagick

# Blurred images

[SmartDeblur](https://github.com/Y-Vladimir/SmartDeblur)

# Zsteg

Detect stegano-hidden data in PNG and BMP files

[Link](https://github.com/zed-0xff/zsteg/)

# Stegsolve

Quickly apply multiple filters on an image

Use arrows to navigate filters

Once a filter shows hidden pixels, use `Analyse > Data Extract` to extract the binary data

# OutGuess

Same as Zsteg but for JPGs

# LSB stegano

[StegHide](https://www.kali.org/tools/steghide/)

# Passwords

Brute-force passwords hidden in images

[Stegseek](https://github.com/RickdeJager/stegseek)

# AperiSolve

Overall scanner for hidden data

# File formats

[LSB steganography](https://github.com/DimitarPetrov/stegify)

## BMP

http://www.ece.ualberta.ca/~elliott/ee552/studentAppNotes/2003_w/misc/bmp_file_format/bmp_file_format.htm

## JPEG

[Change JPEG dimensions](https://github.com/tritoke/ctf-scripts/blob/main/change_jpeg_dimensions.py)

```bash
# extract thumbnail (can be recursive)
exiftool -b -ThumbnailImage ch10.jpg > extract/result.pjg
```

![](img/2023-08-30-23-08-54.png)

## PNG

Headers between IHDR and IDAT can be reordered, always check on the image that every byte associated to the header has been pasted/removed (before and after)

`pngcheck` can help detect problems

[Header problems description](https://www.nayuki.io/page/png-file-chunk-inspector)

[Fix magic bytes and CRC](https://github.com/tritoke/ctf-scripts/blob/main/png_fix.py)

![](img/PNG.png)

## Animated PNG [APNG]

Disassembler = apngdis


# HDMI capture

TempestSDR

# Radio & RTL-SDR

TODO: complete

## Spectral analysis

[Decoder](https://www.dcode.fr/analyse-spectrale)

# White space steganography

`stegsnow` hides data in whitespaces at the end of lines

## Whitespace language

Ternary version of `snow`

[Decoder](https://ideone.com/3BsIJz)

# Password database

`kdbx` files:
- brute force with John
- open with [online app](https://app.keeweb.info/)

# Printer yellow dots

```python
ROW_VALUES = [0, 64, 32, 16, 8, 4, 2, 1]
LAST_COLUMN = 0x0E
SEPARATOR_COLUMN = 0x09

def get_colmun_value(matrix, column):
    row = 0
    value = 0
    if column == SEPARATOR_COLUMN:
        return 0
    for c, e in enumerate(matrix):
        if c % (LAST_COLUMN + 1) == column:
            if e == 'X':
                value += ROW_VALUES[row]
            row += 1
    return value


def print_columns(matrix):
    for column in range(LAST_COLUMN + 1):
        print(column, get_colmun_value(matrix, column))


def decode(matrix):
    year = get_colmun_value(matrix, 0x07)
    month = get_colmun_value(matrix, 0x06)
    day = get_colmun_value(matrix, 0x05)
    print(f"Date:\t20{year:02d}-{month:02d}-{day:02d}")
    hour = get_colmun_value(matrix, 0x04)
    minute = get_colmun_value(matrix, 0x01)
    print(f"Time:\t{hour:02d}:{minute:02d}")
    print(
            "Serial:\t"
            f"{get_colmun_value(matrix, 0x0D):02d}"
            f"{get_colmun_value(matrix, 0x0C):02d}"
            f"{get_colmun_value(matrix, 0x0B):02d}"
            f"{get_colmun_value(matrix, 0x0A):02d}"
          )

# 0 is empty, X is filled
dots = """
X0XXX0XXX0X0X0X
X00000000000X00
X00000000000000
X0000X0000XXX00
0000XX0X00XXX00
0X0000XX00XXXX0
0000XXXX00X00X0
XX00XXX0000X000
""".replace('\n', '')

decode(dots)
```

# Twitter encode messages

[Decoder/encoder](https://holloway.nz/steg/)
