`file` linux command to reveal true type of file

# Web domain or IP address

Check `whois`, `DNS records`, other websites on same server, etc...
```bash
docker run -it scorpix06/webosint
```

# Vim swap files

```bash
# restore vim swap file
vim -r file.swp
```

# Email dump

`.pst` file -> `readpst` package


# RAM dump

Plugins:
- `hashdump` get users' hashes

Recover file:
```bash
# get list of files
vol.py -f “/path/to/file” windows.filescan

# get file at offset found in previous step
vol.py -f “/path/to/file” -o “/path/to/dir” windows.dumpfiles ‑‑physaddr <offset>
```


[Cheatsheet](https://blog.onfvp.com/post/volatility-cheatsheet/)

[Volatility](https://github.com/volatilityfoundation/volatility)

# Sound

[Audacity](http://sourceforge.net/projects/audacity/)

# Radio signals

[Inspectrum](https://github.com/miek/inspectrum)

# Windows credentials

Takes as input Windows hive files (registry files)

[Creddump](https://github.com/moyix/creddump)

# Network captures

Extracts files, images, emails, passwords from capture files

[NetworkMiner](https://www.netresec.com/?page=NetworkMiner)

# NT_USER.dat

[Shellbags](https://github.com/williballenthin/shellbags)

# Binwalk

`Binwalk` tool for searching a given binary image for embedded files and executable code. Specifically, it is designed for identifying files and code embedded inside of firmware images

# Recording to music sheet

[Melody scanner](https://melodyscanner.com)

# Hard drives and smartphones

`Autopsy` is an easy to use, GUI-based program that allows you to efficiently analyze hard drives and smart phones. It has a plug-in architecture that allows you to find add-on modules or develop custom modules in Java or Python.

`Sleuth Kit` is a collection of command line tools and a C library that allows you to analyze disk images and recover files from them. It is used behind the scenes in Autopsy and many other open source and commercial forensics tools.

[Link](https://www.sleuthkit.org/)

# iPhones dump

[iLeapp](https://github.com/abrignoni/iLEAPP)

# Rubber ducky binaries

Inject commands to run on the computer

[Decoder](./ducky-decode.pl -f /chemin/vers/le/file.bin)
