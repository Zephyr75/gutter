# Decompiler

[Python decompiler](https://github.com/zrax/pycdc)

Ghidra

https://dogbolt.org/

# Disassembler

Radare2

Print all symbols, methods, ... in binary executable

![](img/2023-08-31-14-56-11.png)
