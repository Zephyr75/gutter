# First rule

Always run `checksec` first to detect defenses in place

# Tools

`GNU debugger [gdb]` standard Linux debugger

![](img/2023-08-31-14-52-06.png)

![](img/2023-08-31-14-52-25.png)

## GDB Enhanced Features [GEF]

`GDB Enhanced Features [GEF]` improved GDB for exploits

Installation:
```bash
# via the install script
## using curl
bash -c "$(curl -fsSL https://gef.blah.cat/sh)"

## using wget
bash -c "$(wget https://gef.blah.cat/sh -O -)"

# or manually
wget -O ~/.gdbinit-gef.py -q https://gef.blah.cat/py
echo source ~/.gdbinit-gef.py >> ~/.gdbinit
```

Removal: remove **source ...** line from your .gdbinit

Usage:
```bash
checksec # check what securities are active
vmmap 
heap chunks
registers # print all registers
telescope # find ...
context # print context

disas main # disassemble main method
jump *0x<address> # jump to an address
x/100s $sp # print 100 characters after stack pointer
```

## Pwntools

`Pwntools` Python library to automate exploits both locally and remotely

Create template:
```bash
pwn template <binary> > sploit.py
```

Select exploit target:
```python
io = process(“./vulnerable_executable”) # sploit local binary
io = remote(“ctf.epfl.ch”, 31337)       # sploit some guy’s server
```

Basic commands:
```python
io.send(b”Hello\n”)
io.sendline(b”Hello”)
io.sendafter(b”Hi”, b”Hello”)
io.sendlineafter(...)

received = io.recv(6)
received = io.recvline()
received = io.recvuntil(b”Hello”)
received = io.recvall(timeout=1)

log.info(“aaargh”)
log.warn(“aaargh”)
log.error(“aaargh”)
log.debug(“aaargh”)
log.success(“aaargh”)
log.failure(“aaargh”)
log.warn_once(“aaargh”)

b64e(bytes);  b64d(str)  # Base64 encode/decode
enhex(bytes); unhex(str) # Hex encode/decode
p64(integer); u64(bytes) # Pack / unpack integer in little endian
p32(integer); u32(bytes) # Same as above, but for 32 bits

b.symbols[“func1”] || b.symbols.func1 # addr of func1

# instead of io = process(“./binary”), we can do:
io = gdb.debug(“./binary”)
# This will spawn a new terminal with gdb attached to your exploit
```

# Attack types

`Temporal error`

```c
void vulnerable (char *buf) {
    free(buf);
    buf[12]=42;
}
```

`Spatial error`

```c
void vulnerable () {
    char buf[12];
    char * ptr = buf[11];
    *ptr++ = 10;
    *ptr = 42;
}
```

`Format string`
- **Code injection**: place shell code in string itself
- **Code reuse**: encode fixed gadget offsets and invocation frames
- **Advanced code reuse**: recover gadget offsets, then encode them on-the-fly

`Type confusion attacks` 
- Control 2 pointers of different types on single memory area
- Different interpretation of fields leads to "opportunities"


# Stack summary

![Stack layout](img/memory.gif) 

![Memory layout](img/2023-10-06-17-54-11.png)

`Program counter` stack register that manages the memory address of the instruction to be executed next

`Stack frame` element of the stack with a return address, input parameters, local variables and register savings

`Base pointer` address of the beginning of the stack in a frame -> allows restoring parent frame stack


# Vocabulary

`Linked functions` common functions stored on disk so they can be reused by multiple programs (like std methods)

`Global Offset Table [GOT]` section inside of programs that holds addresses of functions that are dynamically linked




