# Basics of CPU

![](img/2023-08-30-01-34-00.png)

Combinational logic = `Arithmetic Logic Unit [ALU]`

Memory is the `Random Access Memory [RAM]`, it holds the `stack` and the `heap`

In general, a CPU executes an instruction by fetching it from memory, using its ALU to perform an operation, and then storing the result to memory

# Vocabulary

`Trusted hardware` A piece of hardware can be trusted if it always behaves in the expected manned for the intended purpose

`Attestation` It can be prove that it does what you think it does
- Attest there is secure hardware
- Attest the state of the OS
- Attest state of the code
- `Secure boot`

`Sealing` It can store secrets in unprotected memory
- The device derives a key that is tied to its current status and stores the encrypted data
- Data can only be decrypted by a device with the same status

`Isolation` It is not possible to peek inside
- Requires protection against side channel attacks
- Trusted hardware offers one well identified entry-point to interact with the software
- `Tamper resistance` hard to open
- `Tamper evident` You can see if it has been opened
- `Tamper responsive` Delete keys when attacked
- Resistance to side channel attacks and physical probing

`Trusted Execution Environments (TPM)` Isolated processing environment in which applications can be securely executed irrespective of the rest of the application
- `Dedicated devices` Strong physical protections
- `Secure enclaves` Prtected regions of memory
- Enable processes to run while being protected from attacks perpetrated by the OS, hypervisor, firmware, drivers, or remote attackers

`Hardware Secure Module (HMS)`
- The user need to know the the public key of the HMS

`Non-volatile Storage`
- `Endorsement key` (EK)
	- Created at manufacturing time
	- Signed by manufacturer
	- Cannot be changed
	- Used for attestation
- `Storage Root Key` (SRK)
	- Used for encrypted storage
- `OwnerPassword`
- They are private and never leave the TPM

`Platform Configuration registers`

`Side channels` Determine the secret key of a cryptographic device by measurign its execution time, its power consumption, or its electromagnetic field
- Learn how the system’s secret by observing how different computations are
- Difficult to create trusted hardware resitent to side channel

> For trusted hardware we need to trust the manufacturer
