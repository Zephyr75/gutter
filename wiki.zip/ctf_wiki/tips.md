Use terminal without ls and cat:
```bash
# ls
echo *

# cat
echo "$(<filename)"
```

Spawn shell inside vim: !/bin/bash

~ at the end of url downloads backup file

`sudo -l` prints all available sudo commands

List of all possible exploits with sudo abilities:
[GTFO bins](https://gtfobins.github.io/)
