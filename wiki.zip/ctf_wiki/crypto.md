# Common encryption schemes

`One Time Pad [OTP]` XOR with a pre-shared string of random bits as long as the message  

`OATH` is a standard that describes:
- How OTPs are generated from a seed
- An XML fomat for importing the seeds into a authentication server

`Homomorphic encryption` form of encryption that allows computations to be performed on encrypted data without first having to decrypt it

`Memory-Hard Function [MHF]` function that costs a significant amount of memory to evaluate

`Memory-Bound Function [MBF]` function that incurs cost by slowing down computation through memory latency

Common formats:
- base64
- ascii
- rot
- alphabet substitution
- hex
- vigenere
- xor
- sha 0, 1, 2, 3

Rare formats to think about:
- deafish
- zodiac
- ascon

## Tools

[CyberChef](https://gchq.github.io/CyberChef/)

[dCode](https://www.dcode.fr/identification-chiffrement)

`JohnTheRipper` all-in-one tool to decrypt passwords

```bash
# convert to John compatible format
zip2john/rar2john/keepass2john <filename> > hashes.txt

# brute force
john --wordlist=<filename> hashes.txt
```

TODO: featherduster


# Symmetric encryption

## Stream Ciphers

Fixed size pre-shared key k + initialization vector IV (unpredictable but not secret + not reusable under the same key) = stream(k, IV)  
We then XOR the stream with the message. This generates a pseudo random stream i.e. unless one knows the key, one cannot distinguish it from a random string.   
-> Similar to one time pad.

## Block cyphers

Key: short random string. Short key size blocks. We need to use this block by block, how?

1. Electronic CodeBook [ECB]

![](img/2023-08-29-12-34-33.png)
![](img/2023-08-29-12-36-26.png)

2. Cipher Block Chaining [CBC] -> subject to bitflips attacks

![](img/2023-08-29-12-36-46.png)
![](img/2023-08-29-12-36-53.png)

3. Counter mode [CTR]

![](img/2023-08-29-12-39-26.png)
![](img/2023-08-29-12-39-30.png)

4. Propagating Cipher Block Chaining [PCBC]

![](img/2023-08-29-12-37-54.png)
![](img/2023-08-29-12-38-02.png)

5. Cipher Feedback [CFB]

![](img/2023-08-29-12-38-36.png)
![](img/2023-08-29-12-38-40.png)

6. Output Feedback [OFB]

![](img/2023-08-29-12-39-05.png)
![](img/2023-08-29-12-39-13.png)

# Integrity

`Digital signature` encoded version of (symmetric secret key, message) to verify that the secret of Bob is actually correct

## Message Authentication Code 

`Message Authentication Code [MAC]` encoded version of the message sent alongside it

`Hash-based MAC [HMAC]` specific MAC involving a cryptographic hash function and a secret cryptographic key

![](img/2023-08-29-18-53-41.png)

where:
- H is a cryptographic hash function.
- m is the message to be authenticated
- K is the secret key
- K' is a block-sized key derived from the secret key, K; either by padding to the right with 0s up to the block size, or by hashing down to less than or equal to the block size first and then padding to the right with zeros.
- || denotes concatenation
- ⊕ denotes bitwise exclusive or (XOR)
- *opad* is the block-sized outer padding, consisting of repeated bytes valued 0x5c
- *ipad* is the block-sized inner padding, consisting of repeated bytes valued 0x36

`Cipher Block Chaining Message Authentication Code [CBC-MAC]` The following figure sketches the computation of the CBC-MAC of a message comprising blocks $m_1 || m_2 || ⋯ m_x$ using a secret key k and a block cipher E: 

# Secure storage

- Hash the password
- `Salt` the password = add a public salt to the password to make sure identical passwords have different hashes

![](img/2023-08-29-18-57-47.png)

## Rainbow tables

`Reduction function` creates a possible password from a hash

PWD1 -hash-> HASH1 -reduction-> PWD2 -hash-> HASH2 -reduction-> PWD3 -> ...

Only store PWD1 and last HASH -> try many more possible passwords than the amount stored

To find PWD from HASH: 
- if it's in the stored HASHes -> done
- else: use reduction then hash on the HASH
    - if the result is in the stored HASHes -> recreate the chain from PWD1
    - else: use reduction then hash again

![](img/2023-08-30-01-10-45.png)

# Asymmetric cryptography

Hash-functions properties:
- `Pre-image resistance` given h(x), hard to recover x
- `Second pre-image resistance` given h(x), hard to find x' s.t. h(x')=h(x)
- `Collision resistance` hard to find x, x' such that h(x') = h(x)

Hybrid encryption:
1. establish a shared symmetric key using "key transport"
2. use the shared symmetric key for the rest of the conversation

## Diffie-Hellman exchange

1. Alice and Bob agree on a natural number n and a generating element g in the finite cyclic group G of order n. (This is usually done long before the rest of the protocol; g is assumed to be known by all attackers.) The group G is written multiplicatively.
2. Alice picks a random natural number a with 1 < a < n, and sends the element $g^a$ of G to Bob.
3. Bob picks a random natural number b with 1 < b < n, and sends the element $g^b$ of G to Alice.
4. Alice computes the element $(g^b)^a = g^{ba}$ of G.
5. Bob computes the element $(g^a)^b = g^{ab}$ of G.  

-> $g^{ab} = g^{ba}$ serves as the shared secret key

> Diffie-Hellman is used in TLS/HTTPS for secure transfer

## RSA

1. Choose 2 distinct prime numbers p and q
2. Compute their product n=pq
3. Compute $\phi(n)=(p-1)(q-1)$
4. Choose a prime number e < $\phi(n)$ called the exponent
5. Compute d such that d*e = 1 (mod n) and e < $\phi(n)$ through the Euclidean algorithm

(n,e) is the public key, d is the private key

### Decrypting

M is an integer representing the message, C is the encoded message

$C = M^e \text{(mod n)}$

### Encrypting

$M = C^d \text{(mod n)}$

## El Gamal

TODO: el gamal

## Paillier

TODO: Paillier

# Tokens

Offline-initialization: Token and server establish a common seed and synchronize their clock

From-then-on operations: $v = f^{\frac{now-start}{interval}}(seed)$

